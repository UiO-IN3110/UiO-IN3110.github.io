from instapy.python_filters import python_color2gray, python_color2sepia


def test_color2gray(image):
    # run color2gray
    ...
    # check that the result has the right shape, type
    ...
    # assert uniform r,g,b values
    ...


def test_color2sepia(image):
    # run color2sepia
    ...
    # check that the result has the right shape, type
    ...
    # verify some individual pixel samples
    # according to the sepia matrix
