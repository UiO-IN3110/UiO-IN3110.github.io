from instapy.numpy_filters import numpy_color2gray, numpy_color2sepia

import numpy.testing as nt


def test_color2gray(image, reference_gray):
    ...


def test_color2sepia(image, reference_sepia):
    ...
