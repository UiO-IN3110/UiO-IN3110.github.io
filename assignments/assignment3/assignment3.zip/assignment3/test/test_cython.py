from instapy.cython_filters import cython_color2gray, cython_color2sepia

import numpy.testing as nt


def test_color2gray(image, reference_gray):
    ...


def test_color2sepia(image, reference_sepia):
    ...
