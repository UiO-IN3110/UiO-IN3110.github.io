"""This file is used when invoked as `python -m instapy`"""

if __name__ == "__main__":
    from .cli import main

    main()
